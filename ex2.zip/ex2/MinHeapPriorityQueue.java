public class MinHeapPriorityQueue<K extends Comparable, E> extends SortedArrayPriorityQueue {

    ArrEntry<K,E> heapPQ[];

    protected void upHeap()
    protected void downHeap() //vun xuống
}